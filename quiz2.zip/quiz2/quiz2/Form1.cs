﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace quiz2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            bool validData = true;
            foreach (Control control in this.Controls)
            {
                if (control is TextBox)
                {
                    TextBox textbox = control as TextBox;
                    validData &= !string.IsNullOrWhiteSpace(textbox.Text);
                }
            }

           textBox1.Enabled = validData;
            
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
           this.TraverseControlsAndSetTextEmpty(this);
        }

        private void TraverseControlsAndSetTextEmpty(Control control)
        {
            foreach (Control c in control.Controls)
            {
                var box = c as TextBox;
                if (box != null)
                {
                    box.Text = string.Empty;
                }

                this.TraverseControlsAndSetTextEmpty(c);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                System.IO.FileStream wFile;
                byte[] byteData = null;
                byteData = Encoding.ASCII.GetBytes("FileStream Test");
                wFile = new FileStream("C:\\Register.txt", FileMode.Append);
                wFile.Write(byteData, 0, byteData.Length);
                wFile.Close();
            }
            catch (IOException ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }


    /*private void clear_icrs_button_Click(object sender, EventArgs e)
    {
        this.TraverseControlsAndSetTextEmpty(this);
    }

    private void TraverseControlsAndSetTextEmpty(Control control)
    {
        foreach (Control c in control.Controls)
        {
            var box = c as TextBox;
            if (box != null)
            {
                box.Text = string.Empty;
            }

            this.TraverseControlsAndSetTextEmpty(c);
        }
    }

    */

    public class  User 

    {
         private String fname { get; set; }
         private String lname { get; set; }
        private String tel { get; set; }

        public User(String fname, String lname, String tel)
        {
           
        }

       /* static void Main(string[] args)
        {
            
        }
        */
    }
    
}


/*1-Create a class user which has 3 fields (fname, lname, tel) 
  2-When the user enters these fields populate user object.

Buttons Functions
Clear Form:
Clears the textboxes and make them empty.
Register:

1-	First need to check that all the fields are being filled and if no, you need to show message to the user that(field[fname / lname / tel]) is empty
2-	If all the fields are filled then open/create a file name it ‘users’ and save the user into that file
Users: 

['first name’: fname1, 'last name’: lname1, 'telephone’: tel1], 
['first name’: fname2, 'last name’: lname2, 'telephone’: tel2],

3-	No need to check if the user exists or not!

Count of Users:
need to open the file and count how many users you have added into the file and show the number by using messagebox.
[you can count how many lines you added in the file!] 

Delete Users:
will delete the file of users that you have created.


Use Git and create a new repository and Push your code into that repository and send the git link to me.


*/
