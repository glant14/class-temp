﻿namespace CarWashSystem
{
    partial class CarwashForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.makecmb = new System.Windows.Forms.ComboBox();
            this.CarGroup = new System.Windows.Forms.GroupBox();
            this.YearLabel = new System.Windows.Forms.Label();
            this.ModelLabel = new System.Windows.Forms.Label();
            this.Yearcmb = new System.Windows.Forms.ComboBox();
            this.Modelcmb = new System.Windows.Forms.ComboBox();
            this.MakeLabel = new System.Windows.Forms.Label();
            this.OwnerGroup = new System.Windows.Forms.GroupBox();
            this.TeleLabel = new System.Windows.Forms.Label();
            this.LastNameLabel = new System.Windows.Forms.Label();
            this.FirstNameLabel = new System.Windows.Forms.Label();
            this.ResetBtn = new System.Windows.Forms.Button();
            this.SaveBtn = new System.Windows.Forms.Button();
            this.CarBtn = new System.Windows.Forms.RadioButton();
            this.OwnerBtn = new System.Windows.Forms.RadioButton();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.fnTB = new System.Windows.Forms.TextBox();
            this.lnTB = new System.Windows.Forms.TextBox();
            this.TeleTB = new System.Windows.Forms.TextBox();
            this.CarGroup.SuspendLayout();
            this.OwnerGroup.SuspendLayout();
            this.SuspendLayout();
            // 
            // makecmb
            // 
            this.makecmb.FormattingEnabled = true;
            this.makecmb.Location = new System.Drawing.Point(74, 31);
            this.makecmb.Name = "makecmb";
            this.makecmb.Size = new System.Drawing.Size(108, 21);
            this.makecmb.TabIndex = 2;
            this.makecmb.SelectedIndexChanged += new System.EventHandler(this.makecmb_SelectedIndexChanged);
            // 
            // CarGroup
            // 
            this.CarGroup.Controls.Add(this.YearLabel);
            this.CarGroup.Controls.Add(this.ModelLabel);
            this.CarGroup.Controls.Add(this.Yearcmb);
            this.CarGroup.Controls.Add(this.Modelcmb);
            this.CarGroup.Controls.Add(this.MakeLabel);
            this.CarGroup.Controls.Add(this.makecmb);
            this.CarGroup.Location = new System.Drawing.Point(53, 128);
            this.CarGroup.Name = "CarGroup";
            this.CarGroup.Size = new System.Drawing.Size(275, 200);
            this.CarGroup.TabIndex = 3;
            this.CarGroup.TabStop = false;
            this.CarGroup.Text = "Car Registration";
            this.CarGroup.Enter += new System.EventHandler(this.CarGroup_Enter);
            // 
            // YearLabel
            // 
            this.YearLabel.AutoSize = true;
            this.YearLabel.Location = new System.Drawing.Point(20, 137);
            this.YearLabel.Name = "YearLabel";
            this.YearLabel.Size = new System.Drawing.Size(29, 13);
            this.YearLabel.TabIndex = 7;
            this.YearLabel.Text = "Year";
            // 
            // ModelLabel
            // 
            this.ModelLabel.AutoSize = true;
            this.ModelLabel.Location = new System.Drawing.Point(20, 81);
            this.ModelLabel.Name = "ModelLabel";
            this.ModelLabel.Size = new System.Drawing.Size(36, 13);
            this.ModelLabel.TabIndex = 6;
            this.ModelLabel.Text = "Model";
            // 
            // Yearcmb
            // 
            this.Yearcmb.FormattingEnabled = true;
            this.Yearcmb.Location = new System.Drawing.Point(74, 134);
            this.Yearcmb.Name = "Yearcmb";
            this.Yearcmb.Size = new System.Drawing.Size(108, 21);
            this.Yearcmb.TabIndex = 5;
            // 
            // Modelcmb
            // 
            this.Modelcmb.FormattingEnabled = true;
            this.Modelcmb.Location = new System.Drawing.Point(74, 78);
            this.Modelcmb.Name = "Modelcmb";
            this.Modelcmb.Size = new System.Drawing.Size(108, 21);
            this.Modelcmb.TabIndex = 4;
            // 
            // MakeLabel
            // 
            this.MakeLabel.AutoSize = true;
            this.MakeLabel.Location = new System.Drawing.Point(20, 34);
            this.MakeLabel.Name = "MakeLabel";
            this.MakeLabel.Size = new System.Drawing.Size(34, 13);
            this.MakeLabel.TabIndex = 3;
            this.MakeLabel.Text = "Make";
            // 
            // OwnerGroup
            // 
            this.OwnerGroup.Controls.Add(this.TeleTB);
            this.OwnerGroup.Controls.Add(this.lnTB);
            this.OwnerGroup.Controls.Add(this.fnTB);
            this.OwnerGroup.Controls.Add(this.TeleLabel);
            this.OwnerGroup.Controls.Add(this.LastNameLabel);
            this.OwnerGroup.Controls.Add(this.FirstNameLabel);
            this.OwnerGroup.Location = new System.Drawing.Point(418, 128);
            this.OwnerGroup.Name = "OwnerGroup";
            this.OwnerGroup.Size = new System.Drawing.Size(304, 200);
            this.OwnerGroup.TabIndex = 4;
            this.OwnerGroup.TabStop = false;
            this.OwnerGroup.Text = "Owner";
            // 
            // TeleLabel
            // 
            this.TeleLabel.AutoSize = true;
            this.TeleLabel.Location = new System.Drawing.Point(6, 137);
            this.TeleLabel.Name = "TeleLabel";
            this.TeleLabel.Size = new System.Drawing.Size(58, 13);
            this.TeleLabel.TabIndex = 7;
            this.TeleLabel.Text = "Telephone";
            // 
            // LastNameLabel
            // 
            this.LastNameLabel.AutoSize = true;
            this.LastNameLabel.Location = new System.Drawing.Point(6, 81);
            this.LastNameLabel.Name = "LastNameLabel";
            this.LastNameLabel.Size = new System.Drawing.Size(58, 13);
            this.LastNameLabel.TabIndex = 6;
            this.LastNameLabel.Text = "Last Name";
            // 
            // FirstNameLabel
            // 
            this.FirstNameLabel.AutoSize = true;
            this.FirstNameLabel.Location = new System.Drawing.Point(6, 34);
            this.FirstNameLabel.Name = "FirstNameLabel";
            this.FirstNameLabel.Size = new System.Drawing.Size(57, 13);
            this.FirstNameLabel.TabIndex = 3;
            this.FirstNameLabel.Text = "First Name";
            // 
            // ResetBtn
            // 
            this.ResetBtn.Location = new System.Drawing.Point(141, 358);
            this.ResetBtn.Name = "ResetBtn";
            this.ResetBtn.Size = new System.Drawing.Size(168, 37);
            this.ResetBtn.TabIndex = 7;
            this.ResetBtn.Text = "Reset";
            this.ResetBtn.UseVisualStyleBackColor = true;
            this.ResetBtn.Click += new System.EventHandler(this.ResetBtn_Click);
            // 
            // SaveBtn
            // 
            this.SaveBtn.Location = new System.Drawing.Point(403, 358);
            this.SaveBtn.Name = "SaveBtn";
            this.SaveBtn.Size = new System.Drawing.Size(168, 37);
            this.SaveBtn.TabIndex = 8;
            this.SaveBtn.Text = "Save";
            this.SaveBtn.UseVisualStyleBackColor = true;
            this.SaveBtn.Click += new System.EventHandler(this.SaveBtn_Click);
            // 
            // CarBtn
            // 
            this.CarBtn.AutoSize = true;
            this.CarBtn.Location = new System.Drawing.Point(141, 73);
            this.CarBtn.Name = "CarBtn";
            this.CarBtn.Size = new System.Drawing.Size(41, 17);
            this.CarBtn.TabIndex = 9;
            this.CarBtn.TabStop = true;
            this.CarBtn.Text = "Car";
            this.CarBtn.UseVisualStyleBackColor = true;
            this.CarBtn.CheckedChanged += new System.EventHandler(this.CarBtn_CheckedChanged);
            // 
            // OwnerBtn
            // 
            this.OwnerBtn.AutoSize = true;
            this.OwnerBtn.Location = new System.Drawing.Point(468, 73);
            this.OwnerBtn.Name = "OwnerBtn";
            this.OwnerBtn.Size = new System.Drawing.Size(56, 17);
            this.OwnerBtn.TabIndex = 10;
            this.OwnerBtn.TabStop = true;
            this.OwnerBtn.Text = "Owner";
            this.OwnerBtn.UseVisualStyleBackColor = true;
            this.OwnerBtn.CheckedChanged += new System.EventHandler(this.OwnerBtn_CheckedChanged);
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.FileName = "CarWashFile";
            this.saveFileDialog1.Title = "Browse Saved Files";
            this.saveFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.saveFileDialog1_FileOk);
            // 
            // fnTB
            // 
            this.fnTB.Location = new System.Drawing.Point(108, 31);
            this.fnTB.Name = "fnTB";
            this.fnTB.Size = new System.Drawing.Size(100, 20);
            this.fnTB.TabIndex = 8;
            // 
            // lnTB
            // 
            this.lnTB.Location = new System.Drawing.Point(108, 81);
            this.lnTB.Name = "lnTB";
            this.lnTB.Size = new System.Drawing.Size(100, 20);
            this.lnTB.TabIndex = 9;
            // 
            // TeleTB
            // 
            this.TeleTB.Location = new System.Drawing.Point(108, 130);
            this.TeleTB.Name = "TeleTB";
            this.TeleTB.Size = new System.Drawing.Size(100, 20);
            this.TeleTB.TabIndex = 10;
            this.TeleTB.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // CarwashForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.OwnerBtn);
            this.Controls.Add(this.CarBtn);
            this.Controls.Add(this.SaveBtn);
            this.Controls.Add(this.ResetBtn);
            this.Controls.Add(this.OwnerGroup);
            this.Controls.Add(this.CarGroup);
            this.Name = "CarwashForm";
            this.Text = "Carwash System";
            this.Load += new System.EventHandler(this.CarwashForm_Load);
            this.CarGroup.ResumeLayout(false);
            this.CarGroup.PerformLayout();
            this.OwnerGroup.ResumeLayout(false);
            this.OwnerGroup.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox makecmb;
        private System.Windows.Forms.GroupBox CarGroup;
        private System.Windows.Forms.Label YearLabel;
        private System.Windows.Forms.Label ModelLabel;
        private System.Windows.Forms.ComboBox Yearcmb;
        private System.Windows.Forms.ComboBox Modelcmb;
        private System.Windows.Forms.Label MakeLabel;
        private System.Windows.Forms.GroupBox OwnerGroup;
        private System.Windows.Forms.Label LastNameLabel;
        private System.Windows.Forms.Label FirstNameLabel;
        private System.Windows.Forms.Button ResetBtn;
        private System.Windows.Forms.Button SaveBtn;
        private System.Windows.Forms.RadioButton CarBtn;
        private System.Windows.Forms.RadioButton OwnerBtn;
        private System.Windows.Forms.Label TeleLabel;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.TextBox TeleTB;
        private System.Windows.Forms.TextBox lnTB;
        private System.Windows.Forms.TextBox fnTB;
    }
}

