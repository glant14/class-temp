﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarWashSystem
{


    public partial class CarwashForm : Form
    {   
        public CarwashForm()
        { 
            InitializeComponent();
        }


        private void CarwashForm_Load(object sender, EventArgs e)
        {

        }

        private void CarBtn_CheckedChanged(object sender, EventArgs e)
        {
            if (CarBtn.Checked)
            {
                CarGroup.Enabled = true;
            }
            else
                CarGroup.Enabled = false;
        }

        private void OwnerBtn_CheckedChanged(object sender, EventArgs e)
        {
            if (OwnerBtn.Checked)
            {
                OwnerGroup.Enabled = true;
            }
            else
                OwnerGroup.Enabled = false;
        }

        private void ResetBtn_Click(object sender, EventArgs e)
        {
            //Car side
            makecmb.Text = string.Empty;
            Modelcmb.Text = string.Empty;
            Yearcmb.Text = string.Empty;

            // Owner side
            fnTB.Text = string.Empty;
            lnTB.Text = string.Empty;
            TeleTB.Text = string.Empty;

        MessageBox.Show("Reset Button Works");
            
        }

        private void CarGroup_Enter(object sender, EventArgs e)
        {

        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.InitialDirectory = "C:\\Quiz3Btn";
            saveFileDialog1.Title = "Save text Files";
            saveFileDialog1.CheckFileExists = true;
            saveFileDialog1.CheckPathExists = true;
            saveFileDialog1.DefaultExt = "txt";
            saveFileDialog1.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            saveFileDialog1.FilterIndex = 2;
            saveFileDialog1.RestoreDirectory = true;
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                CarGroup.Text = saveFileDialog1.FileName;
                

                MessageBox.Show("Save Button Works");




            }
           


        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            
        }
        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void makecmb_SelectedIndexChanged(object sender, EventArgs e)
        {
         /*   if (makecmb.Text == "Honda")
            {
                Modelcmb
             
            }
            */
        }
    }
}
